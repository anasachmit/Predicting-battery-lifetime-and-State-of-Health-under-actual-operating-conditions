# -*- coding: utf-8 -*-
# =============================================================================
#   Modele d'ancrage - TechArena 2026, Challenge 1
#
#   Baseline officiel refite + terme de knee ancre en NIVEAU DE SOH.
#   Volontairement simple : c'est une position de reference, destinee a
#   mesurer l'ecart entre notre proxy de metrique et le score reel.
#
#   Graine fixe, aucun acces reseau, aucun chemin absolu.
# =============================================================================
"""Forme du modele

    base(n) = s0 - b * n^0.8                        (baseline officiel)
    n_k     = cycle ou base(n) franchit SOH_k       (ancrage en SOH)
    tau     = n_k / beta
    SOH(n)  = base(n) - c * (exp((n - n_k)/tau) - 1)_+     puis borne

Trois choix, chacun appuye sur une mesure faite sur les 6 cellules publiees.

1. `s0` n'est pas ajuste mais MESURE (mediane des cycles <= 10, moyennee sur
   les cellules : 102.47 %). Son etendue inter-cellules est de 0.84 point de
   SOH et il ne montre pas de dependance a la temperature (pente -0.015 pt/degC,
   p = 0.16). Le laisser libre lui fait absorber une partie du knee et tire s0
   vers 100 %, ce qui biaise toute la trajectoire precoce.

2. Le knee est ancre par le NIVEAU DE SOH ou il demarre, pas par un nombre de
   cycles. Ajuste librement, `n_k` se disperse d'un facteur 6 entre cellules et
   sa carte (T, C) ne rend que R2 = 0.31 ; le niveau de SOH de declenchement,
   lui, tient dans 78-85 % sur les 6 cellules sans dependance visible a T ni a
   C. On estime donc le parametre identifiable. `SOH_k`, `c` et `beta` sont
   ajustes conjointement sur toutes les cellules a la fois.

3. La carte des conditions est ln(b) = w0 + w1 * 1000/T_K, SANS terme en ln(C).
   Justification empirique : a nombre de cycles egal, les paires 0.5C / 1C a
   25 et a 45 degC different de moins de 1.5 point de SOH, et l'ecart change de
   signe au cours de la vie. La pente en ln(C) n'est pas identifiable sur deux
   contrastes ; la laisser libre donne ici un coefficient negatif, c'est-a-dire
   un vieillissement PAR CYCLE plus rapide a 0.5C qu'a 1C, qui s'extrapole en
   aberration vers le coin 55 degC / 0.5C - coin ou aucune cellule n'existe et
   qui tombe hors de l'enveloppe convexe du plan d'experience. Avec w2 = 0 le
   modele passe l'audit de plausibilite sur toute la grille notee ; avec w2
   libre il le rate.

L'effet du C-rate est reel mais il agit par le TEMPS PASSE, pas par cycle :
a duree ecoulee egale, 0.5C conserve 1.6 a 5.6 points de SOH de plus que 1C.
Un terme calendaire est la bonne facon de le capter ; il n'est pas dans ce
modele d'ancrage.
"""
import numpy as np

RANDOM_SEED = 20260101

FADE_P = 0.8          # exposant du baseline officiel
N_MAX = 12000         # longueur de trajectoire renvoyee
SOH_LO, SOH_HI = 0.5, 119.9   # bornes exigees par framework/io.py
REF_CYCLES = 10       # fenetre de mesure de s0


class MyModel:

    def __init__(self):
        self.s0_ = 102.47
        self.soh_k_ = 80.4
        self.c_ = 1.0
        self.beta_ = 4.0
        self.w_ = [0.0, 0.0, 0.0]
        self.fitted_ = False

    # ------------------------------------------------------------------ fit
    def fit(self, cells):
        np.random.seed(RANDOM_SEED)
        from scipy.optimize import least_squares

        data = []
        for cell in cells:
            d = cell.soh.dropna()
            n = d["cycle_number"].to_numpy(float)
            y = d["soh_percent"].to_numpy(float)
            if len(n) < 20:
                continue
            early = y[n <= REF_CYCLES]
            s0 = float(np.median(early)) if len(early) else float(np.median(y[:10]))
            data.append(dict(T=float(cell.temperature_degC),
                             C=float(cell.c_rate), n=n, y=y, s0=s0))
        if not data:
            raise RuntimeError("aucune cellule exploitable")

        self.s0_ = float(np.mean([d["s0"] for d in data]))

        # --- ajustement conjoint : (SOH_k, c, beta) communs, un b par cellule
        m = len(data)
        b0 = [max(d["s0"] - d["y"].min(), 1.0) / d["n"].max() ** FADE_P
              for d in data]
        p0 = np.array([82.0, 1.0, 4.0] + b0, float)
        lo = np.array([60.0, 0.0, 0.2] + [1e-6] * m, float)
        hi = np.array([98.0, 200.0, 60.0] + [5.0] * m, float)

        def resid(p):
            out = []
            for i, d in enumerate(data):
                pred = _traj(d["s0"], p[3 + i], p[0], p[1], p[2], d["n"])
                # chaque cellule pese autant, quel que soit son nombre de cycles
                out.append((pred - d["y"]) / np.sqrt(len(d["n"])))
            return np.concatenate(out)

        rng = np.random.default_rng(RANDOM_SEED)
        best = None
        for k in range(6):
            st = p0 if k == 0 else np.clip(p0 * rng.uniform(0.5, 2.0, len(p0)),
                                           lo, hi)
            try:
                r = least_squares(resid, st, bounds=(lo, hi), max_nfev=20000)
            except Exception:
                continue
            if best is None or r.cost < best.cost:
                best = r
        if best is None:
            raise RuntimeError("ajustement conjoint echoue")

        p = best.x
        self.soh_k_, self.c_, self.beta_ = float(p[0]), float(p[1]), float(p[2])
        b_cell = np.asarray(p[3:], float)

        # --- carte des conditions : ln(b) = w0 + w1 * 1000 / T_K  (w2 = 0)
        Tk = np.array([d["T"] for d in data]) + 273.15
        X = np.column_stack([np.ones(m), 1000.0 / Tk])
        if m >= 2:
            w, *_ = np.linalg.lstsq(X, np.log(b_cell), rcond=None)
            self.w_ = [float(w[0]), float(w[1]), 0.0]
        else:
            self.w_ = [float(np.log(b_cell.mean())), 0.0, 0.0]

        self.fitted_ = True
        print(f"  (ancrage) s0={self.s0_:.2f}  SOH_k={self.soh_k_:.2f}  "
              f"c={self.c_:.3f}  beta={self.beta_:.3f}  w={np.round(self.w_, 4)}")
        return self

    # -------------------------------------------------------------- predict
    def predict_soh(self, temperature_degC, c_rate):
        b = float(np.exp(self.w_[0]
                         + self.w_[1] * 1000.0 / (float(temperature_degC) + 273.15)
                         + self.w_[2] * np.log(float(c_rate))))
        return _traj(self.s0_, b, self.soh_k_, self.c_, self.beta_)


# ------------------------------------------------------------------ helpers
def _traj(s0, b, soh_k, c, beta, n=None):
    n = np.arange(1, N_MAX + 1, dtype=float) if n is None else np.asarray(n, float)
    base = s0 - b * np.power(n, FADE_P)
    nk = float(np.power(max((s0 - soh_k) / max(b, 1e-12), 1e-9), 1.0 / FADE_P))
    tau = nk / max(beta, 1e-3)
    z = np.clip((n - nk) / max(tau, 1e-6), -50.0, 50.0)
    knee = np.where(n > nk, c * np.expm1(z), 0.0)
    return np.clip(base - knee, SOH_LO, SOH_HI)
